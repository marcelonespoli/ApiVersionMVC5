﻿using Microsoft.Web.Http;
using System.Collections.Generic;
using System.Web.Http;

namespace WebApp.Controllers
{
    [ApiVersion("1.0")]
    [RoutePrefix("api/v{version:apiVersion}/values")]
    public class ValuesController : ApiController
    {
        [Route("")]
        public IEnumerable<string> Get()
        {
            return new string[] { "value3", "value2" };
        }

        [Route("{id}")]
        public string Get(int id)
        {
            return "value";
        }

        [Route("get-new-values/{id}/{name}")]
        public string GetNewValues(int id, string name)
        {
            return "new value";
        }

        [Route("get-new-values/{id}/name/{name}")]
        public string GetNewValuesAndNames(int id, string name)
        {
            return "new value";
        }

        [Route("get-new-values/{id}/name")]
        public string GetNewValuesAndNames(int id)
        {
            return "new value";
        }


        // POST api/values
        public void Post([FromBody]string value)
        {
        }

        // PUT api/values/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/values/5
        public void Delete(int id)
        {
        }
    }
}
